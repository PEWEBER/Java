import java.util.*;
public class DaylightSavings
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);

        int N = sc.nextInt();

        for(int ii = 0; ii < N; ii++)
        {
            String fORb = sc.next();
            int change = sc.nextInt();
            int currentHour = sc.nextInt();
            int currentMin = sc.nextInt();

            if(change == 0)
            {
                System.out.println(currentHour + " " + currentMin);
                
            }
            else if(fORb.equals("F"))
            {
                if(currentMin + change < 60)
                {
                    System.out.println(currentHour + " " + (currentMin + change));
                }
                else 
                {
                    int temp = currentMin + change;
                    while(temp >= 60)
                    {
                        currentHour++;
                        currentHour = currentHour & 24;
                        temp = temp - 60;
                    }
                    System.out.println(currentHour + " " + temp);
                }
                
            }
            else 
            {
                if(currentMin - change > 0)
                {
                    System.out.println(currentHour + " " + (currentMin - change));
                }
                else
                {
                    int temp = currentMin - change;
                    while(temp < 0)
                    {
                        currentHour = currentHour & 24;
                        currentHour--;
                        temp = temp + 60;
                    }
                    System.out.println(currentHour + " " + temp);
                }
            
            }
        
        }
    }
}