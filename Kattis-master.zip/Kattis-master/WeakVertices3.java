import java.util.*;
//edge list

public class WeakVertices3
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);

        int N = sc.nextInt();

        while(N != -1)
        {
            int triangle = 0;
            java.util.List<java.util.Map.Entry<Integer,Integer>> pairList = new java.util.ArrayList<>();

            for(int ii = 0; ii < N; ii++)
            {
                for(int jj = 0; jj < N; jj++)
                {
                    int temp = sc.nextInt();
                    if(temp == 1)
                    {
                        if(!pairList.contains(jj))
                        {
                            java.util.Map.Entry<Integer,Integer> pair = new java.util.AbstractMap.SimpleEntry<>(ii, jj);
                            pairList.add(pair);
                        }
                    }
                }
            }
            for(int i = 0; i < N; i++)
            {
                for(int j = 0; j < N; j++)
                {
                    for(int k = 0; k < N; k++)
                    {
                        if(i != j && j != k && k != i)
                        {
                            java.util.Map.Entry<Integer,Integer> compare1 = new java.util.AbstractMap.SimpleEntry<>(i, j);
                            java.util.Map.Entry<Integer,Integer> compare2 = new java.util.AbstractMap.SimpleEntry<>(j, k);
                            java.util.Map.Entry<Integer,Integer> compare3 = new java.util.AbstractMap.SimpleEntry<>(k, i);
                           
                            if(pairList.contains(compare1) && pairList.contains(compare2) && pairList.contains(compare3))
                            {
                             
                                triangle++;
                            }
                        }
                        
                    }
                }
                if(triangle < 1)
                {
                    System.out.print(i + " ");
                }

                triangle = 0; //reset for next line
            }
            System.out.println();
            N = sc.nextInt();
        }
    }
}