import java.util.Scanner;

public class statistics {
    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);
        int count = 0;
       
            while(scanner.hasNext()) 
            {
                int N = scanner.nextInt();
                int maxVal = -1000000;
                int minVal = 1000000;

                for (int i = 0; i < N; i++) 
                {
                    int inputVal = scanner.nextInt();
                    if (inputVal > maxVal) 
                    {
                        maxVal = inputVal;
                    }
                    if (inputVal < minVal) 
                    {
                        minVal = inputVal;
                    }

                }
                count++;
                System.out.println("Case " + count + ": " + minVal + " " + maxVal + " " + (maxVal - minVal));
              
            }
            scanner.close();

    }

}