import java.util.Scanner;
public class TrainPassanger
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        int capacity = scanner.nextInt();
        int stationStops = scanner.nextInt();

        int passangers = 0;
        int trueCount = 0;

        for(int i = 0; i < stationStops; i++)
        { 
            int left = scanner.nextInt();
            int entered = scanner.nextInt();
            int stayedAtStation = scanner.nextInt();

            if(left > passangers)
            {
                break;
            }
            passangers = passangers + entered - left;
            
            if((stayedAtStation > 0 && passangers < capacity) || passangers > capacity || passangers < 0)
            {
                break;
            }
            else
            {
                trueCount++;
            }


        }
        
        if(trueCount == stationStops && passangers == 0)
        {
            System.out.println("possible");
        }
        else
        {
            System.out.println("impossible");
        }

    }
}