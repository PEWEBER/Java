import java.util.Scanner;

public class Eligibility {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int count = scanner.nextInt();

        for (int i = 0; i < (count); i++) {

            String name = scanner.next();
            String studyYear = scanner.next();
            String birthYear = scanner.next();
            int courseNum = scanner.nextInt();

            int studyYearINT = Integer.parseInt(studyYear.substring(0 , 3));
            int birthYearINT = Integer.parseInt(birthYear.substring(0, 3));

            if (studyYearINT >= 2010) 
            {
                System.out.println("" + name + " eligible");
            } 
            else if (birthYearINT >= 1991) 
            {
                System.out.println("" + name + " eligible");
            } 
            else if(courseNum  > 40) 
            {
                System.out.println("" + name + " ineligible");
            } 
            else 
            {
                System.out.println("" + name + " coach petitions");
            }
        }

    }
}