import java.util.Scanner;

public class Solving4Carrots
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        int peopleNum = scanner.nextInt();
        int carrotNum = scanner.nextInt();
        String describe = scanner.nextLine();
        


        System.out.println(carrotNum);

        

    }
}