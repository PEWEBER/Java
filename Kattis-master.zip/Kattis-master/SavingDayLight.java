import java.util.*;
public class SavingDayLight
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        
        while(sc.hasNext())
        {
            String input = sc.nextLine();
            String[] inputArray = input.split(" ");

            String morning = inputArray[3];
            String night = inputArray[4];

            String[] morningArray = morning.split(":");
            String[] nightArray = night.split(":");

            int morningHour = Integer.parseInt(morningArray[0]);
            int morningMin = Integer.parseInt(morningArray[1]);
            int nightHour = Integer.parseInt(nightArray[0]);
            int nightMin = Integer.parseInt(nightArray[1]);

            int hours = nightHour - morningHour;
            int min;
            if(morningMin > nightMin)
            {
                min = (60 - morningMin) + nightMin;
                hours = hours - 1;
            }
            else
            {
                min = nightMin - morningMin;
            }

            System.out.println(inputArray[0] + " " + inputArray[1] + " " + inputArray[2] + " " + hours + " hours " + min + " minutes");
        }
    }
}