import java.util.Scanner;

public class LeftBeehind {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            int first = scanner.nextInt();
            int last = scanner.nextInt();

            if (first == 0 && last == 0) {

                break;
            } 
            if((first + last) == 13) 
            {
                System.out.println("Never speak again.");
            } 
            else if(first > last) 
            {
                System.out.println("To the convention.");
            } 
            else if(first < last) 
            {
                System.out.println("Left beehind.");
            } 
            if(first == last) 
            {
                System.out.println("Undecided.");
            }
        }

    }
}