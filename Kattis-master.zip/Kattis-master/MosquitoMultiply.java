// egg stage = 1 day
// larva, pupa, mosquito = 1 week

// Sunday:
// adult lays E eggs and dies
// every Rth will transform into pupa next Sunday
// every Sth pupa survives

// M P L E R S N

import java.util.Scanner;
public class MosquitoMultiply
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);

        while(scanner.hasNext())
        {
            String[] input = scanner.nextLine().split(" ");

            int mosquitos = Integer.parseInt(input[0]);
            int pupas = Integer.parseInt(input[1]);
            int larvas = Integer.parseInt(input[2]);
            int eggs = Integer.parseInt(input[3]);
            int RthLarva = Integer.parseInt(input[4]);
            int SthPupa = Integer.parseInt(input[5]);
            int N = Integer.parseInt(input[6]);


            for(int ii = 0; ii < N; ii ++)
            {
                //hatch eggs, mosquitos die from last week, pupa die from last week, larva die from last week, eggs become larva
                //eggs
                int eggNum = eggs * mosquitos;

                //mosquitos
                mosquitos = pupas/SthPupa;
                
                //pupa
                pupas =larvas/RthLarva;
                
                //larva
                larvas = eggNum;
               
            }

            System.out.println(mosquitos);

        }
    }
}