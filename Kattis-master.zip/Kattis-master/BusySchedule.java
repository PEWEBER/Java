import java.util.*;
public class BusySchedule
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();

        Map<Integer, Integer> am = new HashMap<>();
        Map<Integer, Integer> pm = new HashMap<>();

        while(N != 0)
        {
            for(int ii = 0; ii < N; ii ++)
            {
                
                String[] input = sc.nextLine().split(" ");
                int[] time = input[1].split(":");
                int hour = (int)time[0];
                int min = (int)time[1];

                if(input[1].equals("a.m."))
                {
                    am.put(hour, min);
                }
                else
                {
                    pm.put(hour, min);
                }

        
            }
      

            N = sc.nextInt();
        }
    }
}