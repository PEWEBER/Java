import java.util.*;
import java.util.LinkedList;
//adjacency list
public class WeakVertices2
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        
        while(N != -1)
        {
            int triangle = 0;
            @SuppressWarnings("unchecked") LinkedList<Integer>[] array = new LinkedList[N];
            //ArrayList<LinkedList> aList = new ArrayList<LinkedList>();
            for(int ii = 0; ii < N; ii++)
            {
                array[ii] = new LinkedList<Integer>();
                for(int jj = 0; jj < N; jj++)
                {
                    int temp = sc.nextInt();
                    if(temp == 1)
                    {
                        if(!array[ii].contains(jj))
                        {
                            //System.out.println("before " + array[ii].toString());
                            array[ii].add(jj);
                            //System.out.println("after " + array[ii].toString());
                        }
                      
                        ///NULL POINTER
                    }
                }
            }

            for(int i = 0; i < N; i++)
            {
                for(int j = 0; j < N; j++)
                {
                    for(int k = 0; k < N; k++)
                    {
                        if(i != j && j != k && k != i)
                        {
                            //System.out.println(i + " " + j + " " + k);
                           
                            if(array[i].contains(j) && array[j].contains(k) && array[k].contains(i))
                            {
                                //System.out.println("trinagle");
                                triangle++;
                            }
                        }
                        
                    }
                }
                if(triangle < 1)
                {
                    System.out.print(i + " ");
                }

                triangle = 0; //reset for next line
            }
            System.out.println();
            N = sc.nextInt();
           
        }
    
    }
}