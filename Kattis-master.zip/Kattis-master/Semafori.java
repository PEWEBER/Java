import java.util.*;

public class Semafori {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int lightNum = sc.nextInt();
        int lengthOfRoad = sc.nextInt();
        
        int minusLightPosition = 0;
        int totalTime = 0;
        int leftOvers = 0;
        boolean red = true;

        for (int ii = 0; ii < lightNum; ii++) 
        {
          int lightPosition = sc.nextInt();
          int redTime = sc.nextInt();
          int greenTime = sc.nextInt();

          totalTime = totalTime + lightPosition - minusLightPosition;
          minusLightPosition = lightPosition;
          leftOvers = totalTime % (redTime + greenTime);

          if(leftOvers < redTime)
          {
            red = true;
          }
          else
          {
            red = false;
          }

          if(red)
          {
            totalTime = totalTime +  redTime - leftOvers;
          }

        }
        totalTime = totalTime + lengthOfRoad - minusLightPosition;
        System.out.println(totalTime);
    }
}
