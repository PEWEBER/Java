import java.util.*;
//adjacency matrix
public class WeakVertices
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();

        while(N != -1)
        {
            int[][] array = new int[N][N];
            int triangle = 0;
            
            for(int ii = 0; ii < N; ii++)
            {
                for(int jj  = 0; jj < N; jj++)
                {
                    array[ii][jj] = sc.nextInt(); //read in the values and put them into the array
                }
            }
            
            for(int i = 0; i < N; i++)
            {
                for(int j = 0; j < N; j++)
                {
                    for(int k = 0; k < N; k++)
                    {
                        if(array[i][j] == 1 && array[j][k] == 1 && array[k][i] == 1) //check for connection
                        {
                            triangle++;
                        }
                    }
                }
                if(triangle < 1)
                {
                    System.out.print(i + " ");
                }

                triangle = 0; //reset for next line
            }
            System.out.println();
            N = sc.nextInt();

            
        }

    }
}