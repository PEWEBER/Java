/* ------------------------------------------------------------------------------------
Paige Weber, L22812475
Dr. Crawley, Computer Graphics
10/17/19
----------------------------------------------------------------------------------------
This program uses the Java libraries swing, awt and openGL to display a 3D neighborhood
of brick houses. Use mouse to adjust rotation.
------------------------------------------------------------------------------------- */

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.net.URL;

import javax.imageio.ImageIO;
import com.jogamp.opengl.awt.GLJPanel;

import javax.swing.*;
import com.jogamp.opengl.*;

import com.jogamp.opengl.util.awt.ImageUtil;
import com.jogamp.opengl.util.gl2.GLUT;
import com.jogamp.opengl.util.texture.Texture;
import com.jogamp.opengl.util.texture.awt.AWTTextureIO;


public class Neighborhood extends GLJPanel implements GLEventListener{
    
    public Camera camera;
    
   // private Camera camera;  // Contains the current view transform and projection.
                             // The user can drag with the mouse to rotate the view.

    private int currentObject;  // Code for the object  displayed in the panel.

    private int currentTexture;  // Code for the texture currently in use.
    
    private String[] textureFileNames = {
            "brick.jpeg"
    };
    
     private Texture[] textures = new Texture[textureFileNames.length];
    
    public static void main(String[] args) {
        JFrame window = new JFrame("Neighborhood");
        Neighborhood panel = new Neighborhood();
        window.setContentPane(panel);
        window.pack();
        window.setLocation(50,50);
        window.setResizable(false);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setVisible(true);
    }
    
    public Neighborhood() {
        super( new GLCapabilities(null) ); // Makes a panel with default OpenGL "capabilities".
        setPreferredSize( new Dimension(500,500) );
        addGLEventListener(this); // A listener is essential! The listener is where the OpenGL programming lives.
    }
    
    // HOUSE #1 DRAWING FUNCTION ----------------------------------------
    public void drawHouse1(GL2 gl){
      
        double[][] vertexList = {{0, -.25, 0}, {0, .25, 0}, {.25, -.25, 0}, {.25, .25, 0},
        						 {0, -.25, .25}, {0, .25, .25}, {.25, -.25, .25}, {.25, .25, .25}, // cube
        							
        						{.25/2, 0, .5}, // top point of roof
        						
        						{-0.001, .05, .1}, {-0.001, -.05, .1}, {-0.001, .05, 0}, {-0.001, -.05, 0}, // door
        						
        						{-.001, -.1, .15}, {-.001, -.15, .15}, {-.001, -.1, .1}, {-.001, -.15, .1},
        						{-.001, .1, .15}, {-.001, .15, .15}, {-.001, .1, .1}, {-.001, .15, .1}}; //window 
        						
        							
        int[][] faceList = {{1, 0, 2, 3}, {5, 4, 6, 7}, {4, 0, 2, 6}, {6, 2, 3, 7},
        					{7, 3, 1, 5}, {5, 1, 0, 4}, {8, 4, 6}, {8, 6, 7}, {8, 7, 5}, {8, 5, 4},
        					{9, 11, 12, 10}, {13, 15, 16, 14}, {17, 19, 20, 18}};
        					
        
        
       double[][] normalVectors = {{0.0,-0.0,0.125},{0.0,-0.0,0.125},{0.0,-0.0625,0.0},
			{0.125,-0.0,0.0},{0.0,0.0625,0.0},{-0.125,-0.0,-0.0},{0.0,-0.0625,0.0625},
			{0.125,-0.0,0.0625},{0.0,0.0625,0.0625},{-0.125,-0.0,0.0625},{-0.01,-0.0,-0.0},
			{-0.0025,-0.0,-0.0},{0.0025,-0.0,0.0}};		
			
	   double[][] textureList = {{0, 0}, {0, 1}, {1, 1}, {1, 0}};		
        
		
		textures[0].enable(gl);
		for (int i = 0; i < faceList.length; i++) {
			
			gl.glBegin(GL2.GL_TRIANGLE_FAN); 		
			for (int j = 0; j < faceList[i].length; j++) {
				int vertexNum = faceList[i][j]; // Index for vertex j of face i.
				double[] vertexCoords = vertexList[vertexNum]; // The vertex itself.
				
				if( i < 6)
				{
					gl.glTexCoord2d(textureList[j][0], textureList[j][1]);
				}
				
				
        		
        		gl.glNormal3dv(normalVectors[i], 0);
        		
				gl.glVertex3dv( vertexCoords, 0 );
			}
			gl.glEnd();  //!!!! MUST be in this position. Outside of the 
							//brackets will cause rendering error.
		} 
        gl.glEnable(GL2.GL_NORMALIZE);
        gl.glDisable(textures[0].getTarget());
    
    }
    //-------------------------------------------------------------------
    
    // HOUSE #2 DRAWING FUNCTION ----------------------------------------
    public void drawHouse2(GL2 gl)
    {
    
    	double[][] vertexList = {{-.25, .25, 0}, {-.25, 0, 0}, {0, 0, 0}, 
        						 {0, -.25, 0},{.25, -.25, 0}, {.25, .25, 0},
        						 {-.25, .25, .25}, {-.25, 0, .25}, {0, 0, .25}, 
        						 {0, -.25, .25},{.25, -.25, .25}, {.25, .25, .25},
        						 {0, .25, 0}, {0, .25, .25}, //house
        						 
        						 {-.15, -.001, .1}, {-.15, -.001, 0}, // door
        						 {-.1, -.001, 0}, {-.1, -.001, .1}}; 
        						
        							
        int[][] faceList = {{0, 1, 2, 12}, {12, 3, 4, 5}, {6, 7, 8, 13}, {13, 9, 10, 11},
        					{6, 0, 1, 7}, {7, 1, 2, 8}, {8, 2, 3, 9},
        					{9, 3, 4, 10}, {10, 4, 5, 11}, {11, 5, 0, 6},
        					{14, 15, 16, 17}};
        					
        
        
       double[][] normalVectors = {{0.0,-0.0,0.0625},{0.0,-0.0,0.125},{0.0,-0.0,0.0625},
								   {0.0,-0.0,0.125},{-0.0625,0.0,0.0},{0.0,-0.0625,0.0},
								   {-0.0625,-0.0,-0.0},{0.0,-0.0625,0.0},{0.125,-0.0,0.0},
								   {0.0,0.125,0.0},{0.0,-0.005,0.0}};
	
	double[][] textureList = {{0, 0}, {0, 1}, {1, 1}, {1, 0}};	
	
	
	 
	 textures[0].enable(gl);
		for (int i = 0; i < faceList.length; i++) {
			gl.glBegin(GL2.GL_TRIANGLE_FAN); 	
			
				
			for (int j = 0; j < faceList[i].length; j++) {
				int vertexNum = faceList[i][j]; // Index for vertex j of face i.
				double[] vertexCoords = vertexList[vertexNum]; // The vertex itself.
        		
        		if( i != 10 && i != 2 && i != 3) {
        			gl.glTexCoord2d(textureList[j][0], textureList[j][1]);
        		}
        		
        		gl.glNormal3dv(normalVectors[i], 0);
        		
				gl.glVertex3dv( vertexCoords, 0 );
			}
			gl.glEnd();  //!!!! MUST be in this position. Outside of the 
							//brackets will cause rendering error.
		} 
        gl.glEnable(GL2.GL_NORMALIZE); 
        gl.glDisable(textures[0].getTarget());
    }
      //-------------------------------------------------------------------
    
    
    
    
    public void display(GLAutoDrawable drawable) {    
       
        GL2 gl = drawable.getGL().getGL2();
        //GL2 gl2 = drawable.getGL().getGL2();
        
        // Clear The Screen And The Depth Buffer
        gl.glClear (GL2.GL_COLOR_BUFFER_BIT |  GL2.GL_DEPTH_BUFFER_BIT );
        
        gl.glLoadIdentity();  // Reset The View 

        gl.glEnable(GL4.GL_DEPTH_TEST); // NEED THIS FOR IT TO DISPLAY CORRECTLY*/
        
        camera.apply(gl);
        
        
        // draw houses
       for(int i = 3; i > 0; i--)
       {
       		// push position onto stack, translate, go back to original spot
       		gl.glPushMatrix();
       		 gl.glTranslatef(i * .75f, 0, 0);
       		 drawHouse2(gl);
       		gl.glPopMatrix();
       		 
       		 gl.glPushMatrix();
        	 gl.glTranslatef(i * .75f, .75f, 0);
       		 drawHouse1(gl);
       		 gl.glPopMatrix();
       		 
       }
        
        
    } // end display()

    public void init(GLAutoDrawable drawable) {
           // called when the panel is created
           	camera = new Camera();
        	camera.lookAt(2,2,6, 0,0,0, 0,1,0);
        	camera.setScale(1.2);
        	camera.installTrackball(this);
        	
        	
		// adapted from TextureDemo.java
		GL2 gl = drawable.getGL().getGL2();
		//GL2 gl2 = drawable.getGL().getGL2();
        gl.glClearColor(0,0,0,1);
        gl.glEnable(GL2.GL_LIGHTING);
        gl.glEnable(GL2.GL_LIGHT0);
        gl.glEnable(GL2.GL_DEPTH_TEST);
        gl.glLightModeli(GL2.GL_LIGHT_MODEL_TWO_SIDE, 1);
        gl.glMaterialfv(GL2.GL_FRONT_AND_BACK, GL2.GL_AMBIENT_AND_DIFFUSE, new float[] { 1,1,1,1 }, 0);
        gl.glMaterialfv(GL2.GL_FRONT_AND_BACK, GL2.GL_SPECULAR, new float[] { 0.3f, 0.3f, 0.3f, 1 }, 0);
        gl.glMateriali(GL2.GL_FRONT_AND_BACK, GL2.GL_SHININESS, 100);
        gl.glLightModeli(GL2.GL_LIGHT_MODEL_COLOR_CONTROL, GL2.GL_SEPARATE_SPECULAR_COLOR);
        
        
        for (int i = 0; i < textureFileNames.length; i++) {
            try {
                URL textureURL;
                textureURL = getClass().getClassLoader().getResource(textureFileNames[i]);
                if (textureURL != null) {
                    BufferedImage img = ImageIO.read(textureURL);
                    ImageUtil.flipImageVertically(img);
                    textures[i] = AWTTextureIO.newTexture(GLProfile.getDefault(), img, true);
                    textures[i].setTexParameteri(gl, GL2.GL_TEXTURE_WRAP_S, GL2.GL_REPEAT);
                    textures[i].setTexParameteri(gl, GL2.GL_TEXTURE_WRAP_T, GL2.GL_REPEAT);
                }
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void dispose(GLAutoDrawable drawable) {
            // called when the panel is being disposed
    }

    public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {
            // called when user resizes the window
    }
    
}