/* ------------------------------------------------------------------------------------
Paige Weber, L22812475
Dr. Crawley, Computer Graphics
11/13/19
----------------------------------------------------------------------------------------
This program uses the Java libraries swing, awt and openGL to display a 3D house with
open windows at night time. Through the window you can see a table with a 
hexagonal bipyramid on top. Dr. Eck's camera function is used so the user can rotate
the objects with their mouse.
------------------------------------------------------------------------------------- */


Resources used for this assignment:

	- Dr. Ecks Camera class found in the textbook
	- Past programs of my own
	- For lighting I used the following:
		https://www.tutorialspoint.com/jogl/jogl_lighting.htm
		https://www.cse.msu.edu/~cse872/tutorial3.html

